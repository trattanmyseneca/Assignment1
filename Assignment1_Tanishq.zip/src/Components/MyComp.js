import React from 'react';

class MyComponent extends React.Component
{
    render()
    {
        return <h1>Hi inside my component</h1>
    }
}

export default MyComponent;
